/*Driver App Configuration*/

var krms_driver_config ={	
	'ApiUrl':"http://mealoop.com/driver/api",					
	'DialogDefaultTitle':"Mealoop Driver",	
	'PushProjectID':"957384344808",	
	'APIHasKey':"fed7b441b349bae8f146711fbd215e90"
};